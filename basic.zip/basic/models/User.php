<?php

namespace app\models;
use Yii;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
class User extends ActiveRecord implements IdentityInterface
{
    public $id;
    public $username;
    public $password;
    public $authKey;
    public $accessToken;

   /* private static $users = [
        '100' => [
            'id' => '100',
            'username' => 'admin',
            'password' => 'admin',
            'authKey' => 'test100key',
            'accessToken' => '100-token',
        ],
        '101' => [
            'id' => '101',
            'username' => 'demo',
            'password' => 'demo',
            'authKey' => 'test101key',
            'accessToken' => '101-token',
        ],
    ];*/
   
    public static function tableName()
    {
        return 'user';
    }
    public function rules()
    {
        return [
           
			[[ 'username'], 'required'],
            [['username', 'password_hash', 'authKey', 'accessToken'], 'string', 'max' => 255],
        ];
    }
 /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'username' => 'Username',
            'password_hash' => 'Password Hash',
            'authKey' => 'AuthKey',
            'accessToken' => 'AccessToken',
            'created_date' => 'Created Date',
        ];
    }
    /**
     * {@inheritdoc}
     */ 
    public static function findIdentity($id)
    {
        return static::findOne(['id' => $id]);
    }
    /**
     * {@inheritdoc}
     */
	 public static function findIdentityByAccessToken($token, $type = null)
    { 
   	   $user = User::find()->where(['accessToken'=> $token ])->one();
   	   return $user; 
    } 

    /**
     * Finds user by username
     *
     * @param string $username
     * @return static|null
     */
	public static function findByUsername($username)
    {
        return static::findOne(['username' => $username]);
    } 
   

    /**
     * {@inheritdoc}
     */
    public function getId()
    {
        return $this->getPrimaryKey();
    }

    /**
     * {@inheritdoc}
     */
    public function getAuthKey()
    {
        return $this->authKey;
    }

    /**
     * {@inheritdoc}
     */
    public function validateAuthKey($authKey)
    {
        return $this->authKey === $authKey;
    }

    /**
     * Validates password
     *
     * @param string $password password to validate
     * @return bool if password provided is valid for current user
     */
	public function validatePassword($password)
    {
        return Yii::$app->security->validatePassword($password, $this->password_hash);
    }
}
