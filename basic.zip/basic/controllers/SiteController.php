<?php

namespace app\controllers;

use Yii;
use yii\helpers\Url;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use app\models\Category;
use app\models\Item;

class SiteController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        if (!Yii::$app->user->isGuest) {
        return $this->redirect(['category/categories']);
        } else {
			return $this->redirect(['login']);
		}
    }

    /**
     * Login action.
     *
     * @return Response|string
     */
    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        } 
        $model = new LoginForm();
        if ( $model->load(Yii::$app->request->post()) && $model->login() ) {
            return $this->redirect(Url::toRoute(['category/categories'])); 
        } else {
            return $this->render('login', [
                'model' => $model,
            ]);
        }
        $model->password = '';
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    /**
     * Logout action.
     *
     * @return Response
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

 	public function actionCategories()
    {
		if (!Yii::$app->user->isGuest) {
        $models = Category::find()->orderby(['created_date' => SORT_DESC])->all();
	    return $this->render('categories', [
            'models' => $models,
        ]);
        } else {
			return $this->redirect(['login']);
		}
       
    }
	public function actionAddcategory(){
	    if (!Yii::$app->user->isGuest) {
        $model = new Category();
		if ($model->load(Yii::$app->request->post())) {
		$model->save();
		return $this->redirect(Url::toRoute(['site/categories']));
 		}	
 		return $this->render('addcategory', [
            'model' => $model,
        ]);  
        } else {
			return $this->redirect(['login']);
		}	
	}
	public function actionEditcategory($id){
	    if (!Yii::$app->user->isGuest) {
        $model = Category::find()->where(['id'=> $id])->one();
		if ($model->load(Yii::$app->request->post())) {
		$model->save();
		return $this->redirect(Url::toRoute(['site/categories']));
 		}	
 		return $this->render('editcategory', [
            'model' => $model,
        ]);  
        } else {
			return $this->redirect(['login']);
		}	
	}
	public function actionViewcategory($id){
	if (!Yii::$app->user->isGuest) {
        $model = Category::find()->where(['id'=> $id])->one();
		 
		return $this->render('viewcategory', [
            'model' => $model,
        ]);
        } else {
			return $this->redirect(['login']);
		}	
	}
	
 	public function actionDeletecategory(){
	if (!Yii::$app->user->isGuest) {
      $id= $_POST['id'];
	  $category = Category::find()->Where(['id'=> $id])->one();	
	  if($category){
		  $category->Delete();
		  return "success";
	  }	 
    } else {
			return $this->redirect(['login']);
    }	 	
	}
	public function actionItems()
    {
		if (!Yii::$app->user->isGuest) {
        $models = Item::find()->joinwith(['category'])->orderby(['created_date' => SORT_DESC])->all();
	    return $this->render('items', [
            'models' => $models,
        ]);
        } else {
			return $this->redirect(['login']);
		}
       
    }
}
