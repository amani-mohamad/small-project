<?php

namespace app\controllers;

use Yii;
use yii\helpers\Url;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use app\models\Category;
use app\models\Item;

class ItemController extends Controller
{
    /**
     * {@inheritdoc}
     */
    
	public function actionItems()
    {
		if (!Yii::$app->user->isGuest) {
        $models = Item::find()->joinwith(['category'])->orderby(['created_date' => SORT_DESC])->all();
	    return $this->render('items', [
            'models' => $models,
        ]);
        } else {
			return $this->redirect(['site/login']);
		}
       
    }
}
