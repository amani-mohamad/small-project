<?php

namespace app\controllers;

use Yii;
use yii\helpers\Url;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use app\models\Category;
use app\models\Item;

class CategoryController extends Controller
{
  	public function actionCategories()
    {
		if (!Yii::$app->user->isGuest) {
        $models = Category::find()->orderby(['created_date' => SORT_DESC])->all();
	    return $this->render('categories', [
            'models' => $models,
        ]);
        } else {
			return $this->redirect(['site/login']);
		}
       
    }
	public function actionAddcategory(){
	    if (!Yii::$app->user->isGuest) {
        $model = new Category();
		if ($model->load(Yii::$app->request->post())) {
		$model->save();
		return $this->redirect(Url::toRoute(['categories']));
 		}	
 		return $this->render('addcategory', [
            'model' => $model,
        ]);  
        } else {
			return $this->redirect(['site/login']);
		}	
	}
	public function actionEditcategory($id){
	    if (!Yii::$app->user->isGuest) {
        $model = Category::find()->where(['id'=> $id])->one();
		if ($model->load(Yii::$app->request->post())) {
		$model->save();
		return $this->redirect(Url::toRoute(['categories']));
 		}	
 		return $this->render('editcategory', [
            'model' => $model,
        ]);  
        } else {
			return $this->redirect(['site/login']);
		}	
	}
	public function actionViewcategory($id){
	if (!Yii::$app->user->isGuest) {
        $model = Category::find()->where(['id'=> $id])->one();
		 
		return $this->render('viewcategory', [
            'model' => $model,
        ]);
        } else {
			return $this->redirect(['site/login']);
		}	
	}
	
 	public function actionDeletecategory(){
	if (!Yii::$app->user->isGuest) {
      $id= $_POST['id'];
	  $category = Category::find()->Where(['id'=> $id])->one();	
	  if($category){
		  $category->Delete();
		  return "success";
	  }	 
    } else {
			return $this->redirect(['site/login']);
    }	 	
	}
	 
}
