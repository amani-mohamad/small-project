<?php

/* @var $this yii\web\View */

use yii\helpers\Html;
use yii\helpers\Url;
$this->title = 'Items';
$this->params['breadcrumbs'][] = $this->title;
?>
 
<div class="site-about">
    <h1 class="titlecategory"><?= Html::encode($this->title) ?></h1>
     <table id="categories" class="table table-striped table-bordered" style="width:100%"> 
	<thead>
		<tr>
			<th>Id</th>
			<th>Caetgory    </th> 
			<th>Name    </th> 
			<th>Price    </th> 
 			<th>Created date</th>  
		</tr>
	</thead>
 	<tbody>
	<?php if($models){ ?>
	<?php foreach($models as $model){ ?>
	<tr class="model<?= $model->id?>">
	<td><?= $model->id ?></td>
	<td><?= $model->category->name ?></td>
	<td><?= $model->name ?></td> 
	<td><?= $model->price ?></td> 
 	<td><?= $model->created_date ?></td>  
	</tr>
	<?php }?>
	<?php }?>
    </tbody> 
	</table>
</div>
<script>
$(document).ready(function() {
     $('#categories').DataTable();
}); 
</script>