<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'Category detail';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h4> ID</h4>
    <p><?= $model->id ?> </p>
    <h4> Name</h4>
    <p><?= $model->name ?> </p>
</div>
