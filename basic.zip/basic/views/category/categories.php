<?php

/* @var $this yii\web\View */

use yii\helpers\Html;
use yii\helpers\Url;
$this->title = 'Categories';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">DELETE</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Do you want to delete this?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">NO</button>
        <a href="#delete"><button type="button" class="btn btn-primary clicktodelete" data-id="">YES</button></a>
      </div>
    </div>
  </div>
</div>
<div class="site-about">
    <h1 class="titlecategory"><?= Html::encode($this->title) ?></h1>
	<a class="addcategory" href="<?= Url::to(['category/addcategory']) ?>">+ Add</a>
    <table id="categories" class="table table-striped table-bordered" style="width:100%"> 
	<thead>
		<tr>
			<th>Id</th>
			<th>Name    </th> 
			<th>Description    </th> 
 			<th>Created date</th> 
			<th>Action</th> 
		</tr>
	</thead>
 	<tbody>
	<?php if($models){ ?>
	<?php foreach($models as $model){ ?>
	<tr class="model<?= $model->id?>">
	<td><?= $model->id ?></td>
	<td><?= $model->name ?></td> 
	<td><?= $model->description ?></td> 
 	<td><?= $model->created_date ?></td> 
	<td>
	<a href="<?= Url::to(['category/editcategory/','id'=>$model->id ]) ?>" class="iconedit" ></a>
	<a href="<?= Url::to(['category/viewcategory/','id'=>$model->id ]) ?>" class="iconview" ></a>
 	<a href="#" data-id="<?php echo $model->id ?>" class="icondelete" data-toggle="modal" ></a>
 	<!--<a href="#" data_id="<?php echo $model->id ?>" class="icondelete" data-toggle="modal" data-target="#deletemodal" ></a>-->
	</td> 
	</tr>
	<?php }?>
	<?php }?>
    </tbody> 
	</table>
</div>
<script>
$(document).ready(function() {
	$(".icondelete").click(function(e) { 
		var id= $(this).attr('data-id'); 
		$('#deletemodal').modal('show'); 
		$(".clicktodelete").attr("data-id", id);
	});
	$(".clicktodelete").click(function(e) { 
		var id= $(this).attr('data-id'); 
		$.ajax({
						url: '<?php echo Yii::$app->getUrlManager()->createUrl(''); ?>category/deletecategory',
						type: 'post',
						data: {id:id},
						dataType: "text",
						success: function (result) {
							if(result=="success"){
							$('.model'+id ).remove();
							$('#deletemodal').modal('hide'); 	
							} 
						}
					}); 
	});
    $('#categories').DataTable();
}); 
</script>